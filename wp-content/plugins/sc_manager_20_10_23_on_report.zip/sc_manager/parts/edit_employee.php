<div class="float_form" id="float_form_edit">
    <div id="edit_emp" class="new_employee">
        <div class="sc_column_large">
            <div class="sc_top_tabs">
                <?php
                sc_option_tabs('e_pa', '', 'Personal Information', '');
                sc_option_tabs('e_es', '', 'Employee Status', '');
                sc_option_tabs('e_ti', '', 'Tax Information', '');
                sc_option_tabs('e_pai', '', 'Payroll Information', '');
                sc_option_tabs('e_nec', '', 'Emergency Contact', '');
                $infos_emp = array();
                ?>
            </div>
            <div class="sc_tab_render" id='e_emp_pa'> <?php
                                                        $pa_array = [
                                                            "First Name", "Address 1", "Last Name",  "Address 2", "Phone Number",
                                                            "City", "Personal Email", "State", "SSN", "Zip Code", "Gender", "Birth Date"
                                                        ];

                                                        $pa_type = [
                                                            "", "", "",  "", "", "",
                                                            "", "", "", "", "", "date"
                                                        ];
                                                        $pa_lenght = [
                                                            "28", "60", "28",   "60", "20", "60",
                                                            "60", "60", "11", "5", "8", "10"
                                                        ];

                                                        $pa_values = [
                                                            $sc_emp_fname, $emp_adr1, $sc_emp_lname, $emp_adr2, $emp_tel, $emp_city,
                                                            $emp_email, $emp_state, $emp_ssn, $emp_zip, $gender, $emp_bdate
                                                        ];

                                                        for ($i = 0; $i < count($pa_array); $i++) {
                                                            new_ent_detail($i, 'e_pa', $pa_array[$i], $pa_values[$i], $pa_lenght[$i], $pa_type[$i]);
                                                        }

                                                        $emp_fname = $_POST['pa_0'];
                                                        $emp_adr1  = $_POST['pa_1'];
                                                        $emp_lname = $_POST['pa_2'];
                                                        $emp_adr2 = $_POST['pa_3'];
                                                        $emp_tel = $_POST['pa_4'];
                                                        $emp_city = $_POST['pa_5'];
                                                        $emp_email = $_POST['pa_6'];
                                                        $emp_state = $_POST['pa_7'];
                                                        $emp_ssn = $_POST['pa_8'];
                                                        $emp_zip = $_POST['pa_9'];
                                                        $emp_gender = $_POST['pa_10'];
                                                        $emp_bdate = $_POST['pa_11'];

                                                        // echo $emp_fname, $emp_lname . " " . $sel_ent_id;
                                                        ?>
                <div id="e_render_pa"></div>
            </div>

            <div class="sc_tab_render" id='e_emp_es'> <?php
                                                        $es_array = [
                                                            "Employee Access", "Employee Status", "Hire Date", "Termination Date", "Termination Reason",
                                                            "Last Day Worked", "Leave of Absence Start Date", "Leave of Absence Return Date"
                                                        ];
                                                        $es_values = [
                                                            $emp_access, $emp_status, $emp_hire_date, $emp_end_date, $emp_end_reason,
                                                            $emp_last_d_worked, $emp_abs_start_date, $emp_abs_ret_date
                                                        ];

                                                        $es_type = [
                                                            "", "", "date",  "date", "", "date", "date", "date"
                                                        ];
                                                        $es_lenght = [
                                                            "3", "10", "10",  "10", "10", "10", "10", "10"
                                                        ];

                                                        for ($i = 0; $i < count($es_array); $i++) {
                                                            new_ent_detail($i, 'e_es', $es_array[$i], $es_values[$i], $es_lenght[$i], $es_type[$i]);
                                                        }

                                                        $emp_access = $_POST['es_0'];
                                                        $emp_status = $_POST['es_1'];
                                                        $emp_hire_date = $_POST['es_2'];
                                                        $emp_end_date = $_POST['es_3'];
                                                        $emp_end_reason = $_POST['es_4'];
                                                        $emp_last_d_worked = $_POST['es_5'];
                                                        $emp_abs_start_date = $_POST['es_6'];
                                                        $emp_abs_ret_date = $_POST['es_7'];
                                                        ?>
                <div id="e_render_es"></div>
            </div>

            <div class="sc_tab_render" id='e_emp_ti'> <?php
                                                        $ti_array = [
                                                            "Fed MS", "Fed All ($)", "State MS", "State All", "Work State", "County MS"
                                                        ];
                                                        $ti_values = [
                                                            $emp_efed_ms, $emp_fed_all, $emp_state_ms, $emp_state, $emp_work_state, $emp_county_ms
                                                        ];

                                                        $ti_type = ["", "", "",  "", "", ""];
                                                        $ti_lenght = ["50", "50", "60",  "50", "50", "60"];

                                                        for ($i = 0; $i < count($ti_array); $i++) {
                                                            new_ent_detail($i, 'e_ti', $ti_array[$i], $ti_values[$i], $ti_lenght[$i], $ti_type[$i]);
                                                        }

                                                        $emp_efed_ms = $_POST['ti_0'];
                                                        $emp_fed_all = $_POST['ti_1'];
                                                        $emp_state_ms = $_POST['ti_2'];
                                                        $emp_state = $_POST['ti_3'];
                                                        $emp_work_state = $_POST['ti_4'];
                                                        $emp_county_ms = $_POST['ti_5'];
                                                        ?>
                <div id="e_render_ti"></div>
            </div>

            <div class="sc_tab_render" id='e_emp_pai'>
                <?php
                $pai_array = [
                    "Work Email", "Contractor (Y/N)", "Pay Type", "Employee Pay Frequency", "Home Department Number",
                    "Home Department Description", "Pay Rate Amount", "Pay Rate Status", "EE Classification", "Doc Status"
                ];

                $pai_values = [
                    $emp_work_email, $emp_contractor, $emp_pay_type, $emp_pay_freq, $emp_hdep_nbr, $emp_hdep_desc, $emp_pay_rate_amt,
                    $emp_pay_rate_status, $emp_ee_classif, $emp_doc_status
                ];

                $pai_type = [
                    "email", "", "",  "", "", "", "number",
                    "", "", "",
                ];

                $pai_lenght = [
                    "60", "3", "8",  "10", "50", "50", "50",
                    "10", "50", "50",
                ];

                for ($i = 0; $i < count($pai_array); $i++) {
                    new_ent_detail($i, 'e_pai', $pai_array[$i], $pai_values[$i], $pai_lenght[$i], $pai_type[$i]);
                }

                $emp_work_email = $_POST['pai_0'];
                $emp_contractor = $_POST['pai_1'];
                $emp_pay_type = $_POST['pai_2'];
                $emp_pay_freq = $_POST['pai_3'];
                $emp_hdep_nbr = $_POST['pai_4'];
                $emp_hdep_desc = $_POST['pai_5'];
                $emp_pay_rate_amt = $_POST['pai_6'];
                $emp_pay_rate_status = $_POST['pai_7'];
                $emp_ee_classif = $_POST['pai_8'];
                $emp_doc_status = $_POST['pai_9'];
                ?>
                <div id="e_render_pai"></div>
            </div>

            <div class="sc_tab_render" id='e_emp_nec'> <?php
                                                        $nec_array = ["EC Name", "EC Phone", "EC Email"];
                                                        $nec_values = [
                                                            $emp_ec_name, $emp_ec_phone, $emp_ec_email
                                                        ];

                                                        $nec_type = [
                                                            "", "", ""
                                                        ];
                                                        $nec_lenght = [
                                                            "60", "20", "50"
                                                        ];

                                                        for ($i = 0; $i < count($nec_array); $i++) {
                                                            new_ent_detail($i, 'e_nec', $nec_array[$i], $nec_values[$i], $nec_lenght[$i], $nec_type[$i]);
                                                        }


                                                        $emp_ec_name = $_POST['nec_0'];
                                                        $emp_ec_phone = $_POST['nec_1'];
                                                        $emp_ec_email = $_POST['nec_2'];
                                                        ?>
                <div id="e_render_nec"></div>
            </div>

        </div>
        <div class="sc_tab_render" id="emp_edited"></div>
        <!-- <div class="submition_form">  -->
        <div class="decition_btn">
            <div id="nextto_2" class="sc_btns page1">Next<i class='fa fa-arrow-circle-right'></i></div>
            <div id="backto_1" class="sc_btns page2 "><i class='fa-solid fa-arrow-circle-left'></i>Preview</div>
            <div id="nextto_3" class="sc_btns page2 ">Next<i class='fa fa-arrow-circle-right'></i></div>
            <div id="backto_2" class="sc_btns page3 "><i class='fa-solid fa-arrow-circle-left'></i>Preview</div>
            <div id="nextto_4" class="sc_btns page3 ">Next<i class='fa fa-arrow-circle-right'></i></div>
            <div id="backto_3" class="sc_btns page4 "><i class='fa-solid fa-arrow-circle-left'></i>Preview</div>
            <div id="nextto_5" class="sc_btns page4 ">Next<i class='fa fa-arrow-circle-right'></i></div>
            <div id="backto_4" class="sc_btns page5 "><i class='fa-solid fa-arrow-circle-left'></i>Preview</div>

            <div id="save_emp" class="sc_btns">Save <i class="fa fa-save"></i></div>
            <div id="cancel_emp" class="close_form sc_btns">Cancel <i class="fa fa-cancel"></i></div>
        </div>
    </div>
</div>