<?php
global $wpdb;
include('global_function.php');
include('home.css');

// Get the current user's profile information
$current_user = wp_get_current_user();
$sc_user_name = $current_user->user_nicename;
$sc_user_id = $current_user->ID;

// $sc_user_mail = $current_user->user_email;
if (current_user_can('administrator')) {
    $sc_user_position = "Admin";
}

if (current_user_can('editor')) {
    $sc_user_position = "GroupAdmin";
}

if (current_user_can('subscriber')) {
    $sc_user_position = "Editor";
}

if (current_user_can('subscriber')) {
    $sc_user_position = "Visitor";
}

// LOAD ALL VALIDATED EMPLOYEES IN THE LIST
function get_recent_searcheemployee()
{
    global $wpdb, $emp_id, $emp_name, $i;
    foreach ($wpdb->get_results("SELECT emp_id FROM sc_work_for WHERE emp_archive=0") as $key => $row) {
        $i = 1;
        $i++;
        $emp_id = $row->emp_id;
        foreach ($wpdb->get_results("SELECT emp_name FROM sc_employee sc_emp where emp_id=$emp_id") as $key => $row) {
            $emp_name = $row->emp_name; ?>
            <li class="sc_emp">
                <i class="fa-solid fa-chevron-right"></i>
                <a class="ref no_underline" href="<?php echo site_url('/employee') . '?id=' . $emp_id; ?> "><?php echo $emp_name; ?></a>
            </li> <?php
                }
            }
        }


        // LOAD ALL VALIDATED EMPLOYEES IN THE LIST
        function get_employee()
        {
            global $wpdb;
            foreach ($wpdb->get_results("SELECT emp_id FROM sc_work_for WHERE emp_archive=0") as $key => $row) {
                $i = 1;
                $i++;
                $emp_id = $row->emp_id;
                foreach ($wpdb->get_results("SELECT emp_name FROM sc_employee sc_emp where emp_id=$emp_id") as $key => $row) {
                    $emp_name = $row->emp_name;
                    ?>
            <li class="sc_emp">
                <i class="fa-solid fa-chevron-right"></i>
                <a class="ref no_underline" href="<?php echo site_url('/employee') . '?id=' . $emp_id; ?> "><?php echo $emp_name; ?></a>
            </li> <?php
                }
            }
        }

        function get_enterprise_names($value, $order)
        {
            global $wpdb, $i;
            foreach ($wpdb->get_results("SELECT * FROM sc_enterprise  WHERE ent_archive=0 ORDER BY $order ") as $key => $row) {

                $ent_id = $row->ent_id;
                $get_result = $row->$value; ?>
        <li class="sc_emp">
            <i class="fa-solid fa-chevron-right"></i>
            <a class="ref no_underline" href="<?php echo site_url('/enterprise') . '?id=' . $ent_id; ?> "><?php echo $get_result; ?></a>
        </li> <?php
                $_SERVER['ref'] = site_url('/enterprise') . '?id=' . $ent_id;
            }
        }

                ?>

<!-- ---------------------------------------------------------------------------------------------------------App main bloc -->
<div class="welcome_page">
    <!-- -----------------------------------------------------------------------------------------------------App top bar -->
    <?php
    include('layouts/top_bar.php');
    ?>
    <!-- -----------------------------------------------------------------------------------------------------App main content -->
    <div style="display:non" class="sc_content">
        <?php include('layouts/main_left_bar.php'); ////include the header main left bar section 
        ?>

        <!-- -------------------------------------------------------------------------------------------------App main section (right) -->
        <div class="main_box">

            <!-- ---------------------------------------------------------------------------------------------___search bar section -->
            <div class="sc_search_form" action="">
                <h4>What are you looking for today?</h4>

                <div class="input-container">
                    <input type="text" name="sc_search_input" id="sc_search" placeholder="Search">
                    <i class="fas fa-search search-icon"></i>
                </div>
                <div id="search_results"></div>
                <!-- <input type="button" class="sc_search_btn" value="Search"> -->
                <div class="radio_bloc">
                    <div><input type="radio" checked="checked" value="ent" name="search_opt" id="opt_ent"><label for="opt_ent">Enterprises</label></div>
                    <div><input type="radio" value="emp" name="search_opt" id="opt_emp"><label for="opt_emp">Employees</label></div>
                    <input type="hidden" id="sc_from" name="sc_from" value="ent">
                </div>
            </div>

            <!-- ---------------------------------------------------------------------------------------------___recent search section -->
            <div class="sc_result" id="sc_recent_search">
                <div id="sc_recent_ent" class="sc_recent_activ_srch">
                    <div class="load_sc_ent">

                        <!-- ---------------------------------------------------------------------------------________Recent enterprises section -->
                        <span class="sc_recent_activ_label">Recent enterprises searched</span>
                        <div class="sc_ent_bloc">
                            <ul id="sc_ent_list"><?php get_enterprise_names('business_name', 'ent_id'); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="sc_recent_emp" class="sc_recent_activ_srch">
                    <div class="load_sc_emp">

                        <!-- ---------------------------------------------------------------------------------________Recent employees section -->
                        <span class="sc_recent_activ_label">Recent employees searched</span>
                        <div class="sc_emp_bloc">
                            <ul id="sc_emp_list"><?php get_employee(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- <a href="<?php // echo site_url('/employee') . '?id=' . $i; 
                ?>">Njimo Afiro Johnson <img src="<?php //echo IMG . "/profil.png"; 
                                                    ?>" alt=""></a> -->
<script>
    $(document).ready(function() {

        $('#sc_search').keyup(function() {
            $('#search_results').fadeIn();
            if ($('#sc_search').val() == '') {

            } else {

                var query = $('#sc_search').val(); // Get the search query
                var from = $('#sc_from').val(); // Get the search query
                var home = 'home'; // Get the search query
                console.log(home);
                // var query = $(this).val(); // Get the search query

                // Perform an AJAX request to fetch data from the database
                $.ajax({
                    url: '<?php echo sc_URL . "parts/ajax/load_data.php"; ?>', // Replace with the URL of your server-side script
                    method: 'POST',
                    data: {
                        query: query,
                        from: from,
                        home: home
                    },
                    success: function(response) {
                        $('#search_results').html(response); // Display the loaded data in the specified div
                    },
                    error: function() {
                        $('#search_results').html('An error occurred'); // Display an error message
                    }
                });
            }
        });

        $('#search_results').hide();

        $(document).on('click', function(event) {
            var $div = $('#sc_search'); // Replace with the ID of your target div
            var $div2 = $('#search_results'); // Replace with the ID of your target div
            var $target = $(event.target);

            // Check if the clicked element is outside of the target div
            if (!$target.closest($div).length && !$target.is($div)) {
                // Clicked outside of the div
                $('#search_results').fadeOut();
                console.log('Clicked outside of the div');

                // Perform your desired actions here
                // ...
            }

            // Check if the clicked element is outside of the target div
            if (!$target.closest($div2).length && !$target.is($div2)) {
                // Clicked outside of the div
                $('#search_results').fadeOut();
                console.log('Clicked outside of the div');

                // Perform your desired actions here
                // ...
            }
        });

    });
</script>