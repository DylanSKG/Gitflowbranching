<!-- -------------------------------------------------------------------------------------------------App side bar (left) -->
<div class="sc_sidebar">
    <div class="sibarbox"><?php
        dash_item('', 'home.png', 'Home');
        dash_item('userboard', 'dashboard.png', 'Dashboard');
        dash_item('settings', 'engin.png', 'Settings'); ?>
    </div>
</div>