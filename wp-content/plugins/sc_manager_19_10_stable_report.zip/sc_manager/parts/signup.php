<?php
// invoc registration form
    wp_register()
?>