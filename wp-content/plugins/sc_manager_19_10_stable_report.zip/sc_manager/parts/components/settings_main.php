<!-- ====================== SETTINGS MAIN COMPONENTS ==================== -->
<div id="main_pin" class="sub_main">

    <div class="option_main_title"> Personal Information </div>
    <!-- inject the password layouts -->
    <?php include('sections/personal_info.php'); ?>
</div>


<div id="main_pasec" class="sub_main">
    <div class="option_main_title"> Password & Security </div>
    <!-- inject the password layouts -->
    <?php include('sections/pass_secu.php'); ?>
</div>


<div id="main_tms" class="sub_main">
    <div class="option_main_title"> Teams </div>
    <!-- inject the password layouts -->
    <?php include('sections/teams.php'); ?>
</div>


<div id="main_reps" class="sub_main">
    <div class="option_main_title"> Reports </div>
    <!-- inject the password layouts -->
    <?php include('sections/reports.php'); ?>
</div>