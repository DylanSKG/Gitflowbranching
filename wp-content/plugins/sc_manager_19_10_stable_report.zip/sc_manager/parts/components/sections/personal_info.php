    <?php

    $hints = "Your personal information is available and up to date";
    setting_security_states('My Information', $edit_icon, $valid_icon, 'Personal Infos has been set', $hints);
    
    ?>