<?php
// DEFINE PATH
global $wpdb;
/**
 * @return string_seeker_Fucntion
 * This function get a string and crop a specific result base on an interval between a start point (specific character/string) 
 * and an end point (the limit) and sends back the result. it has 2 advance parameters called pivot1 and pivot2 for mouving to 
 * and fro the start point and same for end point respectively
 *
 * @param [string] $the_string Represent the global word/string which has to be treated
 * @param [string] $start the character or set of characters which determine the start point
 * @param [string] $end $start the character or set of characters which determine the start point
 * @param [function] $bond used for additionnal text or string
 * @param [integer] $result
 * 
 * @return Developper : Adrian Deltoro | DeltoroCorp
 * @return version : 1.5.0
 * @return URI : https://facebook.com/deltoro237
 * 
 */

//do not delet or change or modify the below code
if (isset($_REQUEST['id'])) {
    $sel_emp_id = $_REQUEST['id'];
}
// echo $sel_emp_id;
// LOAD ALL VALIDATED EMPLOYEES IN THE LIST
$current_url = $_SERVER['REQUEST_URI'];

foreach ($wpdb->get_results("SELECT * FROM sc_employee sc_emp, sc_work_for sc_for where sc_emp.emp_id=$sel_emp_id and sc_for.emp_archive=0") as $key => $row) {
    $i++;
    // -----------------employee personal information
    $EmployeeID = $row->emp_id;
    $emp_name = $row->emp_name;     // render as first name and last name
    $emp_adr1 = $row->emp_adr1;
    $emp_adr2 = $row->emp_adr2;
    $emp_city = $row->emp_city;
    $emp_state = $row->emp_state;
    $emp_zip = $row->emp_zip;
    $emp_ssn_tin = $row->emp_ssn_tin;
    $emp_ptel = $row->emp_ptel;
    $emp_email = $row->emp_email;
    $emp_bdate = $row->emp_bdate;
    $emp_gender = $row->emp_gender;

    // -----------------employee emergency information
    $emp_ec_name = $row->emp_ec_name;
    $emp_ec_phone = $row->emp_ec_phone;
    $emp_ec_email = $row->emp_ec_email;

    // -----------------employee proffessional information
    $emp_hdep_nbr = $row->emp_hdep_nbr;
    $emp_hdep_desc = $row->emp_hdep_desc;
    $emp_efed_ms = $row->emp_efed_ms;
    $emp_state_ms = $row->emp_state_ms;
    $emp_county_ms = $row->emp_county_ms;
}

function home()
{
    echo '<script>var url = window.location.href;var home_url = url.substring(0, url.indexOf("scman") + "scman".length);location.href = home_url;</script>';
}
function get_employee_details($id, $value)
{
    global $wpdb;
    // $get_id = "no";
    foreach ($wpdb->get_results("SELECT * FROM sc_employee sc_emp, sc_work_for sc_wf where sc_wf.emp_id=$id and emp_archive=0") as $key => $row) {
        $get_result = $row->$value;
        return $get_result;
    }
}

// first column most
// $emp_id = get_employee_details("$sel_emp_id", 'sc_emp.emp_id');
// $emp_name = get_employee_details("$sel_emp_id", 'sc_emp.emp_name');
// $emp_tel = get_employee_details("$sel_emp_id", 'sc_emp.emp_ptel');
// $emp_email = get_employee_details("$sel_emp_id", 'sc_emp.emp_email');
// $emp_ssn = get_employee_details("$sel_emp_id", 'sc_emp.emp_ssn_tin');

// ------------------------------------------------------------------table worked for 
// ---------------------------EMPLOYEE STATUS
$emp_access = get_employee_details("$sel_emp_id", 'emp_access');
$emp_status = get_employee_details("$sel_emp_id", 'emp_status');
$emp_hire_date = get_employee_details("$sel_emp_id", 'emp_hire_date');
$emp_end_date = get_employee_details("$sel_emp_id", 'emp_end_date');
$emp_end_reason = get_employee_details("$sel_emp_id", 'emp_end_reason');
$emp_last_d_worked = get_employee_details("$sel_emp_id", 'emp_last_d_worked');
$emp_abs_start_date = get_employee_details("$sel_emp_id", 'emp_abs_start_date');
$emp_abs_ret_date = get_employee_details("$sel_emp_id", 'emp_abs_ret_date');

$emp_p_amnt = get_employee_details("$sel_emp_id", 'pay_rate_amount');
$emp_ein = get_employee_details("$sel_emp_id", 'pay_rate_status');

$emp_ent_id = get_employee_details("$sel_emp_id", 'emp_ent_id');
$emp_eid = get_employee_details("$sel_emp_id", 'emp_eid');
$emp_ent_id = get_employee_details("$sel_emp_id", 'ent_id');
$emp_work_email = get_employee_details("$sel_emp_id", 'work_email');
$emp_access = get_employee_details("$sel_emp_id", 'emp_access');
$emp_contractor = get_employee_details("$sel_emp_id", 'emp_contract');
$emp_pay_type = get_employee_details("$sel_emp_id", 'emp_pay_type');
$emp_pay_freq = get_employee_details("$sel_emp_id", 'emp_pay_freq');
$emp_pay_rate_amt = get_employee_details("$sel_emp_id", 'emp_pay_rate_amt');
$emp_pay_rate_status = get_employee_details("$sel_emp_id", 'emp_pay_rate_status');
$emp_fed_all = get_employee_details("$sel_emp_id", 'emp_fed_all');
$emp_state_all = get_employee_details("$sel_emp_id", 'emp_state_all');
$emp_work_state = get_employee_details("$sel_emp_id", 'emp_work_state');
$emp_ee_classif = get_employee_details("$sel_emp_id", 'emp_ee_classif');
$emp_doc_status = get_employee_details("$sel_emp_id", 'emp_doc_status');

// second column most
// $emp_adr1 = get_employee_details("$sel_emp_id", 'emp_adr1');
// $emp_adr2 = get_employee_details("$sel_emp_id", 'emp_adr2');
// $emp_city = get_employee_details("$sel_emp_id", 'emp_city');
// $emp_state = get_employee_details("$sel_emp_id", 'emp_state');
// $emp_zip = get_employee_details("$sel_emp_id", 'emp_zip');
// $emp_co_code = get_employee_details("$sel_emp_id", 'emp_ssn_tin');
// $emp_bdate = get_employee_details("$sel_emp_id", 'emp_bdate');
// $emp_gender = get_employee_details("$sel_emp_id", 'emp_gender');
$emp_contact_name = get_employee_details("$sel_emp_id", 'emp_hdep_nbr');

// $emp_email = get_employee_details("$sel_emp_id", 'emp_hdep_desc');


// Get the current user's profile information
$current_user = wp_get_current_user();
$sc_user_name = $current_user->user_nicename;
$sc_user_id = $current_user->ID;
// $sc_user_mail = $current_user->user_email;
$sc_user_position = "Supervisor";

// echo $emp_name;

// employee name presentation
$sc_emp_fname = @string_seeker($emp_name, '', 0, ',', 0, '');
$sc_emp_lname = @string_seeker($emp_name, ',', 1, '', 20, '');
if (!empty($sc_emp_fname) && !empty($sc_emp_lname)) {
    $sc_emp_fullname =  $sc_emp_fname . ", " . $sc_emp_lname;
} elseif (!empty($sc_emp_fname) && empty($sc_emp_lname)) {
    $sc_emp_fullname =  $sc_emp_fname;
} elseif (empty($sc_emp_fname) && !empty($sc_emp_lname)) {
    $sc_emp_fullname =  $sc_emp_lname;
}

// gender presentation
($emp_gender == 'F' || $emp_gender == 'f') ? $gender = 'Female' : $gender = "Male";
if ($emp_gender == '') {
    $gender = '';
}

// ------------------------------------------------------------------ common functions for both pages enterprise, and employee
function dash_item($sc_dash_url, $img_name, $name)
{
    if (empty($sc_dash_url)) {
        $sc_dash_url = '0';
    }
    if (strpos($_SERVER['REQUEST_URI'], $sc_dash_url) > 0) {
        $active = 'sc_active';
    } else {
        $active = '';
    } ?>
    <div class="sidebar_item <?php echo $active; ?>">
        <a class="no_underline" href="<?php echo site_url("$sc_dash_url"); ?>"><span class="sc_item"><img class="img_name" src='<?php echo IMG . "$img_name"; ?>'> <span class="dash_name"><?php echo $name; ?></span></span></a>
    </div> <?php
        }

        function ent_detail($id_ref, $label, $label_value)
        { ?>
    <!-- <a href="" class="links"></a> -->
    <div class="sc_tab_view_box">
        <label for="sc_tab_item" class="sc_tab"><?php echo $label ?></label>
        <span class="sc_tab_item" id="inp_<?php echo $id_ref; ?>"><?php echo $label_value ?></span>
    </div> <?php
        }

        function new_ent_detail($cnt, $id_ref, $label, $label_value, $lenght, $type)
        {  ?>
    <!-- <a href="" class="links"></a> -->
    <div class="sc_tab_view_box">
        <label for="sc_tab_item" class="sc_tab"><?php echo $label ?></label>
        <input class="sc_tab_item" type="<?php echo $type; ?>" id="inp_<?php echo $id_ref . "_" . $cnt; ?>" maxlength="<?php echo $lenght; ?>" name="<?php echo $id_ref . "_" . $cnt ?>" value="<?php $label_value  ?>">
    </div> <?php
        }

        function sc_option_tabs($tab_ref, $tab_state, $tabs_item, $fafa)
        {
            $currentURL = $_SERVER['REQUEST_URI'];
            // echo $currentURL;
            echo ' <div class="sc_tab_bloc "><a href="' . $currentURL . '#tab_' . $tab_ref . '" id="' . $tab_ref . '" class="' . $tab_state . ' no_underline"><span class="sc_tab">' . $tabs_item . '</a><a href="' . $currentURL . '#edit_' . $tab_ref . '" id="a_' . $tab_ref . '" class="' . $tab_state . ' no_underline"><span class="sc_tab"><i title="edit this field" id="i_' . $tab_ref . '" class="fa icons_action option_tab">' . $fafa . '</i></a></div>';
        }

        function string_seeker($the_string, $begin, $pivot1, $end, $pivot2, $bond)
        {
            // global $the_string,$start,$end,$result;

            //search for a basic unit string common to all (http) as a start point
            $start = strpos("$the_string", "$begin");

            //cut the initial strings from its begining and stop infront of the basic unit (http)
            $cut = substr("$the_string", $start + $pivot1);

            //search for a basic unit string common to all (\";) as a stop point
            $stop = strpos($cut, "$end");

            //get the total string extract after the preceeding string cuts interval from start point (0) till the checked point $stop
            $result = substr($cut, 0, $stop + $pivot2) . $bond;
            // echo $the_string;
            return $result;
        }

        // gettint the Meta value by metakey and id function
        function get_mid_by_key($post_id, $meta_key)
        {
            global $wpdb;
            $mid = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM $wpdb->postmeta WHERE post_id = %d AND meta_key = %s", $post_id, $meta_key));
            if ($mid != '')
                // return (int) $mid;
                return $mid;

            return false;
        }
        // Plugin AJAX handler file
        function conn_db($query)
        {
            $connection = mysqli_connect('localhost', 'root', '', 'scman');

            if (!$connection) {
                die('Connection failed: ' . mysqli_connect_error());
            }

            $result = mysqli_query($connection, $query);

            if (!$result) {
                die('Query failed: ' . mysqli_error($connection));
            }
            $connection->query($query);
            $row = mysqli_fetch_assoc($result);
            return $row;
        }
        //random secure string generator
        function secure_random_string($length)
        {
            $random_string = '';
            for ($i = 0; $i < $length; $i++) {
                $number = random_int(0, 36);
                $character = base_convert($number, 10, 36);
                $random_string .= $character;
            }
            return $random_string;
        }

        // ------------------------------------------------------------------------------------Enterprise functions 

        function get_enterprise_details($id, $value)
        {
            global $wpdb;
            // $get_id = "no";
            foreach ($wpdb->get_results("SELECT * FROM sc_enterprise where ent_id=$id  and ent_archive=0") as $key => $row) {
                $get_result = $row->$value;
                return $get_result;
            }
        }

        function ent_emp_detail($ref, $emp_name, $percent)
        {  ?>
    <div class="sc_tab_view_box emp">
        <a href="<?php echo site_url("employee/?id=$ref") ?>" title="employee N°<?php echo $ref; ?>" for="sc_tab_item" class="sc_tab emp_link">
            <span class="sc_tab_item"><?php echo $emp_name ?></span>
        </a>
        <a href="" class="">
            <span class="sc_tab_item emp_percent" id="emp_<?php echo $ref ?>" title=""><?php echo $percent ?></span>
        </a>
    </div> <?php
        }


        //get the employees of this enterprise
        function get_ent_employees($ent_id)
        {
            global $wpdb;
            // loop to get the list of ids of employee related to an enterprise
            foreach ($wpdb->get_results("SELECT (sc_for.emp_id) AS ent_emp_id FROM sc_work_for sc_for, sc_enterprise sc_ent where sc_ent.ent_id=$ent_id and sc_for.ent_id=sc_ent.ent_id  and sc_for.emp_archive=0") as $key => $row) {
                $emp_ids = $row->ent_emp_id; //id gotten

                // loop again to get the list of employee names base on each obtained id
                foreach ($wpdb->get_results("SELECT * FROM sc_employee sc_emp, sc_work_for sc_wf where sc_emp.emp_id=$emp_ids") as $key => $row) {
                    $emp_names = $row->emp_name; //names gotten
                }
                if ($emp_ids == 14 || $emp_ids == 42 || $emp_ids == 24 || $emp_ids == 21 || $emp_ids == 28) { ?><style>
                span#emp_<?php echo $emp_ids; ?> {
                    background-color: red;
                }
            </style><?php
                }
                if ($emp_ids == 24 || $emp_ids == 28 || $emp_ids == 43 || $emp_ids == 33 || $emp_ids == 10 || $emp_ids == 50) { ?><style>
                span#emp_<?php echo $emp_ids; ?> {
                    background-color: orange;
                }
            </style><?php
                }
                // insert both the employees id and name into the enterprise details information bloc format.
                ent_emp_detail($emp_ids, $emp_names, "");
            }
        }


        //get the employees of this enterprise
        function count_employees($ent_id)
        {
            global $wpdb;
            // loop to get the list of ids of employee related to an enterprise
            foreach ($wpdb->get_results("SELECT COUNT(sc_for.emp_id) AS nbr FROM sc_work_for sc_for, sc_enterprise sc_ent where sc_ent.ent_id=$ent_id and sc_for.ent_id=sc_ent.ent_id and sc_for.emp_archive=0") as $key => $row) {
                $counter = $row->nbr; //id gotten
                echo "<span class='counts'>$counter</span>";
            }
        }

        // ----------------------------------------------------------------------------------------Employee Functions



        function emp_enterprise_list($emp_ent_id, $sel_emp_id)
        {
            global $wpdb, $i;
            $i = 1;
            foreach ($wpdb->get_results("SELECT (sc_for.ent_id) AS ent_id FROM sc_work_for sc_for, sc_employee sc_emp where sc_emp.emp_id=$sel_emp_id and sc_for.emp_id=sc_emp.emp_id and sc_for.emp_archive=0") as $key => $row) {
                $emp_ent_id = $row->ent_id;
                foreach ($wpdb->get_results("SELECT * FROM sc_enterprise where ent_id=$emp_ent_id") as $key => $row) {
                    $enterprise = $row->business_name;
                    $i = 0;
                    echo '<a id="ref_' . $i . '" href="' . site_url("enterprise/?id=$emp_ent_id") . '"><option id="ent_' . $emp_ent_id . '" value="' . $emp_ent_id . '" class="_' . $emp_ent_id . ',' . $enterprise . '">' . $enterprise . '</option></a>';
                    $i++;
                }
                $i++;
            }
        }

        function sc_action_buttons($svg_icon, $sc_title, $tab_ref, $tab_state, $tabs_item, $fafa, $svg_id)
        {
            echo ' <a href="' . $tab_ref . '" id="do_' . $svg_id . '" alt="' . $tabs_item . '" title="' . $sc_title . '"  class="no_border action_btns ' . $tab_state . ' no_underline"><span class="icons">' . $tabs_item . '<i class="fa ' . $fafa . '"></i>' . $svg_icon . '</a>';
        }


        // =================================================================================================================================
        // =========================================== Teams constructor functions ===========================================
        // =================================================================================================================================


        function setting_team_states($sec_title, $label, $label_id, $label_conf, $selected)
        { ?> <!-- pin -->
    <div class="s_sub_main">
        <div class="option_main_bloc">
            <div class="option_section">
                <div class="option_section_title">
                    <?php echo $sec_title; ?>
                </div>
                <div class="option_section_state">
                    <div class="team_section"> <?php
                                                for ($i = 0; $i < 3; $i++) { ?>
                            <div class="selectar">
                                <div class="labels">
                                    <label for="enterprise"><?php echo $label[$i]; ?></label>
                                </div>
                                <div class="selects">
                                    <select class="sel_ent" name="enterprise" id="get_<?php echo $label_id[$i]; ?>">
                                        <option value="" id="ent_option">Select</option>
                                    </select>
                                </div>
                                <div class="adders">
                                    <span id="lab_<?php echo $label_id[$i]; ?>" class="trns_btn sc_shadow"><?php echo $label_conf[$i]; ?></span>
                                </div>
                            </div>
                            <div class="added_entity" id="add_ent">
                                <span class="ent_added" id="selected_<?php echo $label_id[$i]; ?>"><?php echo $selected[$i]; ?></span>
                            </div> <?php
                                                } ?>

                    </div>
                </div>
            </div>
        </div>
    </div> <?php
        }


        // =================================================================================================================================
        // =========================================== Setting State constructor functions ===========================================
        // =================================================================================================================================
        function setting_security_states($sec_title, $action_icon, $state_icon, $caption, $hints)
        { ?> <!-- pin -->
    <div class="s_sub_main">
        <div class="option_main_bloc">
            <div class="option_section">
                <div class="option_section_title">
                    <?php echo $sec_title; ?>
                    <span class="icon"><?php echo $action_icon; ?></span>
                </div>
                <div class="option_section_state">
                    <span class="section_icon"><?php echo $state_icon; ?></span>
                    <div class="section_state_caption">
                        <span class="state_caption"><?php echo $caption; ?></span>
                        <span class="section_state_hints"><?php echo $hints; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div> <?php
        }


        // =================================================================================================================================
        // =========================================== Setting State constructor functions ===========================================
        // =================================================================================================================================
        function setting_custom_report_forms($sec_title, $action_icon, $state_icon, $boxes_choice_label, $boxes_choice_attr, $repor_hints, $reports_param_label, $reports_parameter)
        { ?> <!-- pin -->
    <div class="s_sub_main">
        <div class="option_main_bloc">
            <div class="option_section">
                <div class="option_section_title">
                    <?php echo $sec_title; ?>
                    <span class="icon"><?php echo $action_icon; ?></span>
                </div>
                <div class="option_section_state">
                    <span class="section_icon"><?php echo $state_icon; ?></span>
                    <div class="section_state_caption">
                        <div class="form_block">
                            <div class="choice_box">
                                <?php
                                for ($i = 0; $i < count($boxes_choice_label); $i++) {
                                ?>
                                    <span class="check_boxs">
                                        <input type="checkbox" class="ckbx_option" name="<?php echo $boxes_choice_attr[$i]; ?>" id="<?php echo $boxes_choice_attr[$i]; ?>">
                                        <label for="<?php echo $boxes_choice_attr[$i]; ?>"><?php echo $boxes_choice_label[$i]; ?></label>
                                    </span>
                                <?php
                                } ?>
                            </div>
                            <div class="parameter_zone">
                                <span><?php echo $repor_hints; ?></span>
                                <div class="bulk_param">
                                    <?php
                                    for ($i = 0; $i < count($reports_param_label); $i++) { ?>
                                        <span class="check_boxs param_box">
                                            <label class="sel_ent" for="ent"><?php echo $reports_param_label[$i]; ?></label>
                                            <select class="get_ent" name="get_<?php echo substr($reports_param_label[$i], 0, 4); ?>" id="id_<?php echo substr($reports_param_label[$i], 0, 4); ?>">
                                                <option value="" class="options" id="">Select <?php echo $reports_param_label[$i]; ?></option>
                                            </select>
                                        </span>
                                    <?php
                                    } ?>
                                </div>
                                <button class="generate" id="gen">Generate</button>
                                <div class="response"></div>
                                <div class="gen_report"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <?php
        }
