    <?php

    // init vars
    $label = ['Choose enterprise', 'Add team lead', 'Add team members'];
    $label_conf = ['Choose enterprise', 'Add team lead', 'Add team members'];
    $selected = ['360 Support', 'Chenwi Blessing', 'Cedric'];
    $label_id = ['ent', 'lead', 'memb'];

    //call the function
    setting_team_states('Add Team Members', $label,$label_id, $label_conf,$selected);

    ?>